package br.com.alura.springdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
